'use client'

import Link from 'next/link'
import Image from 'next/image'
import { useState, useEffect, useRef } from 'react'
import { QUESTIONS } from '@/data/questions'
import { supabase } from '@/components/supabaseClient'

type Progress = { total: number; answered: number; isComplete: boolean }

async function ensureProfileExists(userId: string) {
  const { data, error } = await supabase
    .from('profiles')
    .select('user_id')
    .eq('user_id', userId)
    .maybeSingle()
  if (error) throw error
  if (!data) {
    const { error: insertError } = await supabase
      .from('profiles')
      .insert([{ user_id: userId }])
    if (insertError) throw insertError
  }
}

async function uploadToElevenLabs(file: Blob, name: string): Promise<string> {
  const form = new FormData()
  form.append('audio', file, name)
  form.append('name', name)
  const res = await fetch('/api/upload-voice', { method: 'POST', body: form })
  if (!res.ok) {
    const text = await res.text()
    throw new Error(`Upload failed: ${text}`)
  }
  const data = await res.json()
  if (!data.voice_id) throw new Error('Invalid upload response')
  return data.voice_id
}

async function previewVoice(voiceId: string): Promise<string> {
  const res = await fetch('/api/generate-voice', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ voiceId, text: 'Hello, this is a preview.' }),
  })
  if (!res.ok) throw new Error(await res.text())
  const blob = await res.blob()
  return URL.createObjectURL(blob)
}

export default function ProfilePage() {
  const [user, setUser] = useState<any>(null)
  const [loadingUser, setLoadingUser] = useState(true)
  const [activeTab, setActiveTab] = useState<'voice'|'personality'>('voice')
  const [progress, setProgress] = useState<Record<string,Progress>>({})
  const [voiceId, setVoiceId] = useState<string|null>(null)
  const [previewUrl, setPreviewUrl] = useState<string|null>(null)
  const [message, setMessage] = useState<string|null>(null)
  const [error, setError] = useState<string|null>(null)
  const [userName, setUserName] = useState('')
  const [uploading, setUploading] = useState(false)
  const [recording, setRecording] = useState(false)
  const mediaRecorderRef = useRef<MediaRecorder|null>(null)
  const audioChunksRef = useRef<Blob[]>([])

  useEffect(() => {
    let mounted = true
    async function load() {
      const { data: sessionData } = await supabase.auth.getSession()
      const me = sessionData.session?.user ?? null
      if (mounted) setUser(me)
      if (me) {
        await ensureProfileExists(me.id)
        const { data, error } = await supabase
          .from('profiles')
          .select('profile_data, voice_id')
          .eq('user_id', me.id)
          .maybeSingle()
        if (!error && data && mounted) {
          const prog: Record<string,Progress> = {}
          Object.entries(QUESTIONS).forEach(([section, qs]) => {
            const answers = data.profile_data?.[section] || {}
            const cnt = qs.filter(q => answers[q.key]?.trim()).length
            prog[section] = { total: qs.length, answered: cnt, isComplete: cnt === qs.length && qs.length > 0 }
          })
          setProgress(prog)
          setVoiceId(data.voice_id)
        }
      }
      if (mounted) setLoadingUser(false)
    }
    load()
    return () => { mounted = false }
  }, [])

  async function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    if (!e.target.files?.[0] || !userName.trim() || !user) return
    setError(null); setMessage(null); setUploading(true)
    const file = e.target.files[0]
    const name = `${userName.trim()}-${Date.now()}`
    try {
      const id = await uploadToElevenLabs(file, name)
      setVoiceId(id)
      await supabase.from('profiles').update({ voice_id: id }).eq('user_id', user.id)
      setMessage('Upload successful!')
    } catch(err:any) {
      setError(err.message)
    } finally {
      setUploading(false)
    }
  }

  async function startRecording() {
    setError(null); setMessage(null); audioChunksRef.current = []
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const recorder = new MediaRecorder(stream)
      mediaRecorderRef.current = recorder
      recorder.ondataavailable = (evt) => {
        audioChunksRef.current.push(evt.data)
      }
      recorder.onstop = async () => {
        setRecording(false); setUploading(true)
        const blob = new Blob(audioChunksRef.current,{ type:'audio/webm' })
        const name = `${userName.trim()}-${Date.now()}`
        try {
          const id = await uploadToElevenLabs(blob, name)
          setVoiceId(id)
          await supabase.from('profiles').update({ voice_id: id }).eq('user_id', user.id)
          setMessage('Upload successful!')
        } catch(err:any) {
          setError(err.message)
        } finally {
          setUploading(false)
        }
      }
      recorder.start(); setRecording(true)
    } catch(err:any) {
      setError(err.message); setRecording(false)
    }
  }
  function stopRecording() { mediaRecorderRef.current?.stop() }

  if (loadingUser) {
    return (
      <main style={{ padding:'2em', color:'#fff', textAlign:'center' }}>
        <p>Loading user session…</p>
      </main>
    )
  }
  if (!user) {
    return (
      <main style={{
        minHeight:'100vh',display:'flex',alignItems:'center',justifyContent:'center',
        color:'#fff',background:'var(--color-bg-voice)'
      }}>
        <p>Please <Link href="/login" style={{ color:'var(--color-primary)' }}>log in</Link>.</p>
      </main>
    )
  }

  return (
    <main
      style={{
        minHeight: '100vh',
        color: '#fff',
        transition: 'background 2s ease-in-out',
        background: 'linear-gradient(120deg, #232946 0%, #413076 50%, #af7ea8 100%)',
        backgroundAttachment: 'fixed',
        backgroundSize: 'cover',
      }}
    >
      <div style={{ textAlign:'center', margin:'2em 0' }}>
        <Image src="/echostone_logo.png" width={200} height={200} alt="EchoStone Logo" />
        <h1>Your Profile</h1>
        <div style={{ display:'flex', justifyContent:'center', gap:8, margin:'1em 0' }}>
          <button
            onClick={()=>setActiveTab('voice')}
            style={{
              ...buttonStyle,
              background: activeTab==='voice'?'var(--color-primary)':'#555',
              cursor: 'pointer'
            }}
          >Voice</button>
          <button
            onClick={()=>setActiveTab('personality')}
            style={{
              ...buttonStyle,
              background: activeTab==='personality'?'var(--color-primary)':'#555',
              cursor: 'pointer'
            }}
          >Personality</button>
        </div>
      </div>
      <div style={{ maxWidth:960, margin:'0 auto', padding:'0 1em' }}>
        {activeTab==='voice' && (
          <aside style={{
            background:'rgba(34,24,56,0.85)',
            borderRadius:16, padding:'2em', boxShadow:'0 4px 20px rgba(0,0,0,0.75)'
          }}>
            <label htmlFor="userName" style={{ display:'block', color:'#fff', marginBottom:8 }}>
              Your Name *
            </label>
            <input
              id="userName" type="text" value={userName}
              onChange={e=>setUserName(e.currentTarget.value)}
              placeholder="Enter your name"
              style={{
                width:200, maxWidth:'100%',
                padding:'0.5em', border:'1px solid #ddd', borderRadius:8,
                marginBottom:16
              }}
            />
            <div style={{ marginBottom:16 }}>
              <input
                id="voiceFileInput" type="file" accept="audio/*"
                onChange={handleFileChange}
                disabled={uploading||recording||!userName.trim()}
                style={{ display:'none' }}
              />
              <label
                htmlFor="voiceFileInput"
                style={{
                  display:'inline-block',
                  cursor: uploading||recording||!userName.trim() ? 'not-allowed':'pointer',
                  opacity: uploading||recording||!userName.trim()?0.5:1,
                  marginBottom:16,
                  ...buttonStyle
                }}
              >
                Choose File…
              </label>
            </div>
            <div style={{ margin:'12px 0', color:'#fff', opacity:0.8 }}>or</div>
            {!recording ? (
              <button
                onClick={startRecording}
                disabled={uploading||!userName.trim()}
                style={{
                  ...buttonStyle,
                  cursor:uploading||!userName.trim()?'not-allowed':'pointer',
                  width:'100%', marginBottom:16
                }}
              >
                🎤 Record In Browser
              </button>
            ) : (
              <button
                onClick={stopRecording}
                style={{
                  ...buttonStyle,
                  background:'var(--color-danger)',
                  width:'100%', marginBottom:16
                }}
              >
                ⏹️ Stop Recording
              </button>
            )}
            <div style={{ display:'flex', alignItems:'center', gap:8, justifyContent:'center', marginTop:16 }}>
              <button
                onClick={async ()=>{
                  setError(null); setMessage('Generating preview…')
                  try{ const url = await previewVoice(voiceId!); setPreviewUrl(url) }
                  catch(err:any){ setError(err.message) }
                  finally{ setMessage(null) }
                }}
                disabled={!voiceId}
                style={{
                  ...buttonStyle,
                  opacity: !voiceId?0.5:1,
                  background:'var(--color-secondary)'
                }}
              >
                🔊 Preview
              </button>
              {previewUrl && <audio controls src={previewUrl} style={{ maxWidth:200 }} />}
            </div>
            {voiceId && (
              <button
                onClick={async ()=>{
                  if (!confirm('Delete your voice clone?')) return
                  await supabase.from('profiles').update({ voice_id: null }).eq('user_id', user.id)
                  setVoiceId(null); setPreviewUrl(null); setMessage(null)
                }}
                style={{
                  ...buttonStyle,
                  background:'var(--color-danger)',
                  marginTop:16,
                  width:'100%'
                }}
              >
                Delete Voice ❌
              </button>
            )}
            {uploading && <p style={{ color:'#ff7b00', marginTop:16 }}>Uploading…</p>}
            {message && <p style={{ color:'#7fffab', marginTop:16 }}>{message}</p>}
            {error && <p style={{ color:'salmon', marginTop:16 }}>{error}</p>}
          </aside>
        )}
        {activeTab==='personality' && (
          <div style={{
            display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(240px,1fr))', gap:16
          }}>
            {Object.entries(QUESTIONS).map(([section, qs]) => {
              const prog = progress[section] || { total: qs.length, answered: 0, isComplete: false }
              return (
                <Link key={section} href={`/profile/edit/${section}`} style={{ textDecoration:'none' }}>
                  <div style={{
                    padding:'1.2em', borderRadius:16,
                    background: prog.isComplete?'rgba(30,10,60,0.96)':'rgba(30,10,60,0.7)',
                    boxShadow:'0 2px 12px #0006', opacity: prog.isComplete?1:0.8
                  }}>
                    <h2 style={{ margin:0, fontSize:'1.2rem', color:'#fff', textTransform:'capitalize' }}>
                      {section.replace(/_/g,' ')}
                    </h2>
                    <p style={{ margin:'0.5em 0', fontSize:'0.9rem', color:'#c2b8e0' }}>
                      {prog.answered} of {prog.total} answered
                    </p>
                    {prog.isComplete && <span style={{ color:'#7fffab', fontSize:'1.5rem' }}>✓</span>}
                  </div>
                </Link>
              )
            })}
          </div>
        )}
      </div>
    </main>
  )
}

const buttonStyle: React.CSSProperties = {
  backgroundColor: 'var(--color-primary)',
  color: '#fff',
  padding: '0.65em 1.5em',
  borderRadius: 8,
  border: 'none',
  fontWeight: 600,
  fontSize: '1em',
  cursor: 'pointer',
  boxShadow: '0 2px 12px rgba(0,0,0,0.3)',
  transition: 'background 0.3s, opacity 0.3s',
}