// src/components/PageShell.tsx
import React from 'react'
import AccountMenu from './AccountMenu'

export default function PageShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="page-shell">
      <AccountMenu />
      <main className="main-content">{children}</main>
    </div>
  )
}